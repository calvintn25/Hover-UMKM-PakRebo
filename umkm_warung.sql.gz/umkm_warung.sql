-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 12, 2024 at 05:40 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `umkm_warung`
--

-- --------------------------------------------------------

--
-- Table structure for table `about_us`
--

CREATE TABLE `about_us` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `about_us`
--

INSERT INTO `about_us` (`id`, `image`, `description`, `created_at`, `updated_at`) VALUES
(3, 'Thumbnail About us.png', 'Pondok Bakso Marem dan Mie Ayam Pak Rebo merupakan salah satu usaha UMKM yang sudah berdiri sejak tahun 2010 hingga saat ini.', '2024-06-09 07:20:16', '2024-06-09 07:20:17'),
(4, 'Thumbnail About us.png', 'Pondok Bakso Marem dan Mie Ayam Pak Rebo merupakan salah satu usaha UMKM yang sudah berdiri sejak tahun 2010 hingga saat ini.', '2024-06-09 07:20:20', '2024-06-09 07:20:20');

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `headers`
--

CREATE TABLE `headers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `headers`
--

INSERT INTO `headers` (`id`, `name`, `slug`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Bakso Urat Super Jumbo', 'bakso-urat-super-jumbo', 'J_urat super.jpg', '2024-06-09 10:05:22', '2024-06-09 10:08:46'),
(2, 'Mie Ayam Bakso', 'mie-ayam-bakso', 'MAB.jpg', '2024-06-09 10:09:23', '2024-06-09 10:09:23'),
(3, 'Nasi Goreng Kampung', 'nasi-goreng-kampung', 'NG_kampung.jpg', '2024-06-09 10:09:40', '2024-06-09 10:09:41');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(6, '0001_01_01_000000_create_users_table', 1),
(7, '0001_01_01_000001_create_cache_table', 1),
(8, '0001_01_01_000002_create_jobs_table', 1),
(9, '2024_05_26_070724_create_product_categories_table', 1),
(10, '2024_06_04_070429_create_products_table', 1),
(11, '2024_06_09_130356_create_about_us_table', 2),
(12, '2024_06_09_163134_create_headers_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_reset_tokens`
--

INSERT INTO `password_reset_tokens` (`email`, `token`, `created_at`) VALUES
('calvintn08@gmail.com', '$2y$12$T7k2xUrRs9RWgpGv2vgLf.gwThx2PZoOeB3mBPcQ5jKpkjgLLanIe', '2024-06-07 20:50:21'),
('test1@gmail.com', '$2y$12$H5p4kTI/BgrSYIvKCnHt.u/MSVrQODLFUVKifME.VpDU3SddcbnGq', '2024-06-07 20:48:03');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `price` double DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `product_category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `slug`, `price`, `image`, `product_category_id`, `created_at`, `updated_at`) VALUES
(38, 'Mie Ayam Bakso Full Telor', 'mie-ayam-bakso-full-telor', 32000, 'MAB_full telor.jpg', 1, '2024-06-09 02:34:44', '2024-06-09 12:35:55'),
(39, 'Mie Ayam Bakso', 'mie-ayam-bakso', 20000, 'MAB.jpg', 1, '2024-06-09 02:36:00', '2024-06-09 02:36:00'),
(40, 'Mie Ayam Telor', 'mie-ayam-telor', 22000, 'MA_telor.jpg', 1, '2024-06-09 02:36:33', '2024-06-09 02:36:33'),
(42, 'Mie Ayam', 'mie-ayam', 15000, 'MA_biasa.jpg', 1, '2024-06-09 02:51:02', '2024-06-09 02:51:02'),
(43, 'Mie Ayam Bakso Full', 'mie-ayam-bakso-full', 32000, 'MAB_full.jpg', 1, '2024-06-09 02:51:42', '2024-06-09 02:51:42'),
(44, 'Mie Ayam Bakso Jumbo', 'mie-ayam-bakso-jumbo', 40000, 'MAB_jumbo.jpg', 1, '2024-06-09 02:52:11', '2024-06-09 02:52:11'),
(45, 'Bakso Jumbo Full Telor', 'bakso-jumbo-full-telor', 40000, 'J_full telor.jpg', 3, '2024-06-09 02:52:53', '2024-06-09 02:52:53'),
(46, 'Bakso Jumbo Plus Telor', 'bakso-jumbo-plus-telor', 30000, 'J_plus telor.jpg', 3, '2024-06-09 02:53:52', '2024-06-09 02:53:52'),
(47, 'Bakso Jumbo Plus Kecil', 'bakso-jumbo-plus-kecil', 30000, 'J_plus kecil.jpg', 3, '2024-06-09 02:54:38', '2024-06-09 02:54:38'),
(48, 'Bakso Urat Super Jumbo', 'bakso-urat-super-jumbo', 25000, 'J_urat super.jpg', 3, '2024-06-09 02:55:42', '2024-06-09 02:55:42'),
(49, 'Bakso', 'bakso', 17000, 'B_biasa.jpg', 2, '2024-06-09 02:56:04', '2024-06-09 02:56:04'),
(50, 'Bakso Telor', 'bakso-telor', 20000, 'B_telor.jpg', 2, '2024-06-09 02:56:26', '2024-06-09 02:56:26'),
(51, 'Bakso Kecil', 'bakso-kecil', 17000, 'B_kecil.jpg', 2, '2024-06-09 02:57:28', '2024-06-09 02:57:28'),
(52, 'Bakso Full', 'bakso-full', 25000, 'B_biasa full.jpg', 2, '2024-06-09 02:57:58', '2024-06-09 02:57:58'),
(53, 'Bakso Full Telor', 'bakso-full-telor', 25000, 'B_full telor.jpg', 2, '2024-06-09 02:58:21', '2024-06-09 02:58:21'),
(54, 'Bihun Goreng', 'bihun-goreng', 16000, 'bihun goreng.jpg', 4, '2024-06-09 02:59:18', '2024-06-09 02:59:18'),
(55, 'Nasi Goreng Kampung', 'nasi-goreng-kampung', 25000, 'NG_kampung.jpg', 4, '2024-06-09 03:01:41', '2024-06-11 06:04:46'),
(56, 'Nasi Goreng Bakso', 'nasi-goreng-bakso', 18000, 'NG_bakso.jpg', 4, '2024-06-09 03:02:18', '2024-06-09 03:02:18'),
(57, 'Nasi Goreng Teri', 'nasi-goreng-teri', 18000, 'NG_teri.jpg', 4, '2024-06-09 03:03:06', '2024-06-09 03:03:06'),
(58, 'Nasi Goreng', 'nasi-goreng', 15000, 'NG_biasa.jpg', 4, '2024-06-09 03:03:45', '2024-06-09 03:03:45'),
(59, 'Kuetiaw Goreng Bakso', 'kuetiaw-goreng-bakso', 20000, 'kwetiaw goreng bakso.jpg', 4, '2024-06-09 03:04:25', '2024-06-09 03:04:25'),
(60, 'Mie Goreng', 'mie-goreng', 16000, 'mie goreng.jpg', 4, '2024-06-09 03:04:52', '2024-06-09 03:04:52'),
(61, 'Teh Obeng / Es Teh Tawar', 'teh-obeng-es-teh-tawar', 6000, 'Teh Obeng.png', 5, '2024-06-09 12:28:43', '2024-06-10 10:53:53'),
(62, 'Teh O Tawar / Manis', 'teh-o-tawar-manis', 6000, 'Teh O.png', 5, '2024-06-09 12:30:03', '2024-06-10 10:54:19'),
(65, 'Kopi Panas / Dingin', 'kopi-panas-dingin', 8000, 'Kopi.png', 5, '2024-06-09 12:32:54', '2024-06-10 10:55:08'),
(66, 'Es Susu', 'es-susu', 10000, 'Es Susu.png', 5, '2024-06-09 12:37:00', '2024-06-10 10:55:46'),
(67, 'Milo', 'milo', 10000, 'Milo.png', 5, '2024-06-09 12:37:28', '2024-06-10 10:56:10'),
(68, 'Jeruk Panas / Dingin', 'jeruk-panas-dingin', 8000, 'Jeruk.png', 5, '2024-06-09 12:37:58', '2024-06-10 10:53:21'),
(69, 'Teh Susu Panas / Dingin', 'teh-susu-panas-dingin', 8000, 'Teh Susu.png', 5, '2024-06-09 12:38:33', '2024-06-10 10:56:54'),
(70, 'Air Mineral Biasa / Dingin', 'air-mineral-biasa-dingin', 5000, 'Air Mineral.png', 5, '2024-06-09 12:38:53', '2024-06-10 10:56:38'),
(71, 'Teh Botol Sosro + Es', 'teh-botol-sosro-es', 6000, 'Teh Sosro.png', 5, '2024-06-09 12:39:45', '2024-06-10 10:54:42');

-- --------------------------------------------------------

--
-- Table structure for table `product_categories`
--

CREATE TABLE `product_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_categories`
--

INSERT INTO `product_categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Mie Ayam', 'mie-ayam', '2024-06-06 23:21:54', '2024-06-10 13:17:06'),
(2, 'Bakso', 'bakso', '2024-06-06 23:22:03', '2024-06-06 23:22:03'),
(3, 'Bakso Jumbo', 'bakso-jumbo', '2024-06-06 23:22:13', '2024-06-06 23:22:13'),
(4, 'Lainnya', 'lainnya', '2024-06-06 23:22:23', '2024-06-06 23:22:23'),
(5, 'Minuman', 'minuman', '2024-06-06 23:22:27', '2024-06-06 23:22:27');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('CKodmbGcN9M1mrLKtwrBQBBLHntL0aSMmVtmHzd7', 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoidUQ3YjV5clhmcFlkNDQ5QVh4UUZnUTJkYlFQNE80NDVuZFcwekFWMyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTE6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9hZG1pbi9wcm9kdWN0cz9zZWFyY2g9bmFzaSUyMCI7fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjM7czo0OiJhdXRoIjthOjE6e3M6MjE6InBhc3N3b3JkX2NvbmZpcm1lZF9hdCI7aToxNzE4MTEwNTIwO319', 1718111639),
('neljI4oz7a5meL7RRFbU6zhgc7Eo5bgzmlvqRqXY', 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoiS1FYa3pMWkhTZkNrbTllTFRoVFowUkFnSUI1V2pTNHhxMDBqQ2V6aSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDY6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9hZG1pbi9wcm9kdWN0LWNhdGVnb3JpZXMiO31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTozO3M6NDoiYXV0aCI7YToxOntzOjIxOiJwYXNzd29yZF9jb25maXJtZWRfYXQiO2k6MTcxODEwNTgyMDt9fQ==', 1718105875);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'test', 'test1@gmail.com', NULL, '$2y$12$q54zl2pER2hDpKdGJvmvH.El9InU6.lFCgGCalQn9yc7G1dtjAJIa', NULL, '2024-06-06 23:21:22', '2024-06-06 23:21:22'),
(2, 'Calvin Tan', 'calvintn08@gmail.com', NULL, '$2y$12$11IETc1/V4GBSqz0Un0MuOQTZvMMssaFZ4CFXNdMyGIKA45/8FWrO', NULL, '2024-06-07 20:48:35', '2024-06-07 20:48:35'),
(3, 'admin', 'admin@gmail.com', NULL, '$2y$12$8mrIJfdSdfxwXGydrKDlMODBW8WB9tylNlQ0CWccSGF6g5hPEcB/u', NULL, '2024-06-11 04:35:50', '2024-06-11 04:35:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about_us`
--
ALTER TABLE `about_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `headers`
--
ALTER TABLE `headers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_product_category_id_index` (`product_category_id`);

--
-- Indexes for table `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about_us`
--
ALTER TABLE `about_us`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `headers`
--
ALTER TABLE `headers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `product_categories`
--
ALTER TABLE `product_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
